import { AfterViewInit, Component, OnInit } from '@angular/core';
import * as AOS from 'aos';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit,AfterViewInit{
  title = 'ajay-resume';
  name = 'Ajay Rangam';
  skills = ['Angular','HTML5','Angular','HTML5','Angular','HTML5','Angular','HTML5','Angular','HTML5','Angular','HTML5','Angular','HTML5'];

  ngOnInit() {
    AOS.init({duration: 1200,});//AOS - 2
    AOS.refresh();//refresh method is called on window resize and so on, as it doesn't require to build new store with AOS elements and should be as light as possible.
  }
  ngAfterViewInit() {
  AOS.refresh();
}
}
